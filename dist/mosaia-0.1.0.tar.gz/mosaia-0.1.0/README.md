# Mosaia SDK

A Python SDK for interacting with the Mosaia API.

## Installation

```bash
pip install mosaia
```

## Usage

```python
from mosaia import Mosaia

mosaia = Mosaia()
```

